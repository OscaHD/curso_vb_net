﻿Namespace Modelo
    Module Constantes
        'Public Const CADENA_CONEX_EXCEL As String = "Provider=Microsoft.ACE.OLEDB.12.0;" &
        '    "Extended Properties='Excel 12.0 Xml;HDR=No';" &
        '    "Data Source="
        Public Const PROVEEDOR_EXCEL = "Microsoft.ACE.OLEDB.12.0"
        Public Const PROPIEDADES_EXCEL = ";Extended Properties='Excel 12.0 Xml;HDR=Yes'"
        Public Const PROVEEDOR_ACCESS As String = "Microsoft.Jet.OLEDB.4.0"
        ' & "Data Source=" ' Justo despues tiene que ir el nombre del fichero
    End Module
End Namespace