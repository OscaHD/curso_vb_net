﻿Namespace Modelo
    Module Constantes
        'Public Const RUTA_EMPLEADOS As String = "C:\Users\sinensia100\"
    End Module
End Namespace