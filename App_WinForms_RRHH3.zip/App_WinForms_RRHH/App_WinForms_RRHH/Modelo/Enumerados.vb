﻿Namespace Modelo
    Public Enum TipoCampoEmpleado
        Nombre
        Apellidos
        Genero
    End Enum
    Public Enum TipoGenero
        Varon = 1
        Mujer = 2
        Hermafrodita = 3
    End Enum
    Public Enum TipoCategoria
        JefeEquipo = 1
        Tecnico = 2
        Administrativo = 3
    End Enum
End Namespace